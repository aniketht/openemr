After enabling the "track_anything"-form, you need to set up the Tracks.

* Go to any encounter and select "Track anything"
* click the button "Configure tracks"
* click the button "Create new Track"
* give it a "name" and a "description"
* use "position" to alter the descending order of tracks/items
* click the "add"-button to add some items to track

* click the "disable" button to hide tracks or items. Note that data of disabled tracks/items will stay in the database. After "enabling" track or items, they will show up again.


If some Tracks are configured...
* got to any encounter,
* select "Track anything"
* select the desired track
* enter your data

