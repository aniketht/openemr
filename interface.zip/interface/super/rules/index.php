<?php
require_once("include/header.php");

$controllerRouter = new ControllerRouter();
$controllerRouter->route();
