<?php
include_once("./globals.php");

?>

<html>
<head>
<?php html_header_show();?>


</head>
<body ONLOAD="javascript:top.location.href='<?php echo "$rootdir/login/login.php"; ?>';">

</body>
</html>
