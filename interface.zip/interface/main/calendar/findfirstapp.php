<?php
include_once("../../globals.php");
include_once("$srcdir/calendar.inc");
include_once("$srcdir/patient.inc");
?>
<html>
<head>
<?php html_header_show();?>

<link rel="stylesheet" href="<?php echo $css_header;?>" type="text/css">

</head>
<body bgcolor="#FFFFFF" >
<form>

<input type=submit value="<?php xl('Find', 'e'); ?>" />

</form>

</body>
</html>
