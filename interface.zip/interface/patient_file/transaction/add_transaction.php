<?php
/**
*
* add_transaction is a misnomer, as this script will now also edit
* existing transactions.
*
*
* LICENSE: This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://opensource.org/licenses/gpl-license.php>.
*
* @package   OpenEMR
* @author    Rod Roark <rod@sunsetsystems.com>
* @author    Brady Miller <brady.g.miller@gmail.com>
* @link      http://www.open-emr.org
*/

require_once("../../globals.php");
require_once("$srcdir/transactions.inc");
require_once("$srcdir/options.inc.php");
require_once("$srcdir/amc.php");

// This can come from the URL if it's an Add.
$title   = empty($_REQUEST['title']) ? 'LBTref' : $_REQUEST['title'];
$form_id = $title;

// Plugin support.
$fname = $GLOBALS['OE_SITE_DIR'] . "/LBF/$form_id.plugin.php";
if (file_exists($fname)) {
    include_once($fname);
}

$transid = empty($_REQUEST['transid']) ? 0 : $_REQUEST['transid'] + 0;
$mode    = empty($_POST['mode' ]) ? '' : $_POST['mode' ];
// $inmode    = $_GET['inmode'];
$body_onload_code = "";

// Load array of properties for this layout and its groups.
$grparr = array();
getLayoutProperties($form_id, $grparr);

if ($mode) {
    $sets = "title = ?, user = ?, groupname = ?, authorized = ?, date = NOW()";
    $sqlBindArray = array($form_id, $_SESSION['authUser'], $_SESSION['authProvider'], $userauthorized);

    if ($transid) {
        array_push($sqlBindArray, $transid);
        sqlStatement("UPDATE transactions SET $sets WHERE id = ?", $sqlBindArray);
    } else {
        array_push($sqlBindArray, $pid);
        $sets .= ", pid = ?";
        $newid = sqlInsert("INSERT INTO transactions SET $sets", $sqlBindArray);
    }

    $fres = sqlStatement("SELECT * FROM layout_options " .
    "WHERE form_id = ? AND uor > 0 AND field_id != '' " .
    "ORDER BY group_id, seq", array($form_id));

    while ($frow = sqlFetchArray($fres)) {
        $data_type = $frow['data_type'];
        $field_id  = $frow['field_id'];
        $value = get_layout_form_value($frow);

        if ($transid) { // existing form
            if ($value === '') {
                $query = "DELETE FROM lbt_data WHERE " .
                "form_id = ? AND field_id = ?";
                sqlStatement($query, array($transid, $field_id));
            } else {
                $query = "REPLACE INTO lbt_data SET field_value = ?, " .
                "form_id = ?, field_id = ?";
                sqlStatement($query, array($value, $transid, $field_id));
            }
        } else { // new form
            if ($value !== '') {
                sqlStatement(
                    "INSERT INTO lbt_data " .
                    "( form_id, field_id, field_value ) VALUES ( ?, ?, ? )",
                    array($newid, $field_id, $value)
                );
            }
        }
    }

    if (!$transid) {
        $transid = $newid;
    }

  // Set the AMC sent records flag
    if (!(empty($_POST['send_sum_flag']))) {
        // add the sent records flag
        processAmcCall('send_sum_amc', true, 'add', $pid, 'transactions', $transid);
        if (!(empty($_POST['send_sum_elec_flag']))) {
            processAmcCall('send_sum_elec_amc', true, 'add', $pid, 'transactions', $transid);
        }
    } else {
        // remove the sent records flags
        processAmcCall('send_sum_amc', true, 'remove', $pid, 'transactions', $transid);
        processAmcCall('send_sum_elec_amc', true, 'remove', $pid, 'transactions', $transid);
    }

    $body_onload_code = "javascript:location.href='transactions.php';";
}

$CPR = 4; // cells per row

function end_cell()
{
    global $item_count, $cell_count;
    if ($item_count > 0) {
        echo "</td>";
        $item_count = 0;
    }
}

function end_row()
{
    global $cell_count, $CPR;
    end_cell();
    if ($cell_count > 0) {
        for (; $cell_count < $CPR;
        ++$cell_count) {
            echo "<td></td>";
        }

        echo "</tr>\n";
        $cell_count = 0;
    }
}

function end_group()
{
    global $last_group;
    if (strlen($last_group) > 0) {
        end_row();
        echo " </table>\n";
        echo "</div>\n";
    }
}

// If we are editing a transaction, get its ID and data.
$trow = $transid ? getTransById($transid) : array();
?>
<html>
<head>

<title><?php echo xlt('Add/Edit Patient Transaction'); ?></title>

<link rel="stylesheet" href="<?php echo $GLOBALS['assets_static_relative'] ?>/bootstrap-3-3-4/dist/css/bootstrap.min.css">
<?php if ($_SESSION['language_direction'] == 'rtl') { ?>
    <link rel="stylesheet" href="<?php echo $GLOBALS['assets_static_relative'] ?>/bootstrap-rtl-3-3-4/dist/css/bootstrap-rtl.min.css">
<?php } ?>
<link rel='stylesheet' href="<?php echo $css_header;?>" type="text/css">
<link rel="stylesheet" type="text/css" href="../../../library/js/fancybox/jquery.fancybox-1.2.6.css" media="screen" />
<link rel="stylesheet" href="<?php echo $GLOBALS['assets_static_relative']; ?>/jquery-datetimepicker-2-5-4/build/jquery.datetimepicker.min.css">

<script type="text/javascript" src="../../../library/textformat.js?v=<?php echo $v_js_includes; ?>"></script>
<script type="text/javascript" src="../../../library/dialog.js?v=<?php echo $v_js_includes; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['assets_static_relative']; ?>/jquery-min-1-7-2/index.js"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['webroot'] ?>/library/js/common.js?v=<?php echo $v_js_includes; ?>"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['webroot'] ?>/library/js/fancybox/jquery.fancybox-1.2.6.js"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['assets_static_relative']; ?>/jquery-datetimepicker-2-5-4/build/jquery.datetimepicker.full.min.js"></script>

<?php include_once("{$GLOBALS['srcdir']}/options.js.php"); ?>

<script type="text/javascript">
$(document).ready(function() {
  if (window.enable_modals) {
    enable_modals();
  }
  if(window.tabbify){
    tabbify();
  }
  if (window.checkSkipConditions) {
    checkSkipConditions();
  }
});

var mypcc = '<?php echo htmlspecialchars($GLOBALS['phone_country_code'], ENT_QUOTES); ?>';

$(document).ready(function(){
  $("#send_sum_flag").click(function() {
    if ( $('#send_sum_flag').attr('checked') ) {
      // Enable the send_sum_elec_flag checkbox
      $("#send_sum_elec_flag").removeAttr("disabled");
    }
    else {
      //Disable the send_sum_elec_flag checkbox (also uncheck it if applicable)
      $("#send_sum_elec_flag").attr("disabled", true);
      $("#send_sum_elec_flag").removeAttr("checked");
    }
  });

  $('.datepicker').datetimepicker({
    <?php $datetimepicker_timepicker = false; ?>
    <?php $datetimepicker_showseconds = false; ?>
    <?php $datetimepicker_formatInput = false; ?>
    <?php require($GLOBALS['srcdir'] . '/js/xl/jquery-datetimepicker-2-5-4.js.php'); ?>
    <?php // can add any additional javascript settings to datetimepicker here; need to prepend first setting with a comma ?>
  });
  $('.datetimepicker').datetimepicker({
    <?php $datetimepicker_timepicker = true; ?>
    <?php $datetimepicker_showseconds = false; ?>
    <?php $datetimepicker_formatInput = false; ?>
    <?php require($GLOBALS['srcdir'] . '/js/xl/jquery-datetimepicker-2-5-4.js.php'); ?>
    <?php // can add any additional javascript settings to datetimepicker here; need to prepend first setting with a comma ?>
  });
});

function titleChanged() {
 var sel = document.forms[0].title;
 // Layouts must not interfere with each other. Reload the document in Add mode.
 top.restoreSession();
 location.href = 'add_transaction.php?title=' + sel.value;
 return true;
}

function divclick(cb, divid) {
 var divstyle = document.getElementById(divid).style;
 if (cb.checked) {
  divstyle.display = 'block';
 } else {
  divstyle.display = 'none';
 }
 return true;
}

// The ID of the input element to receive a found code.
var current_sel_name = '';

// This is for callback by the find-code popup.
// Appends to or erases the current list of related codes.
function set_related(codetype, code, selector, codedesc) {
 var frc = document.forms[0][current_sel_name];
 var s = frc.value;
 if (code) {
  if (s.length > 0) s += ';';
  s += codetype + ':' + code;
 } else {
  s = '';
 }
 frc.value = s;
}

// This invokes the find-code popup.
function sel_related(e) {
 current_sel_name = e.name;
 dlgopen('../encounter/find_code_popup.php<?php if ($GLOBALS['ippf_specific']) {
        echo '?codetype=REF';
} ?>', '_blank', 500, 400);
}

// Process click on Delete link.
function deleteme() {
// onclick='return deleteme()'
 dlgopen('../deleter.php?transaction=<?php echo htmlspecialchars($transid, ENT_QUOTES); ?>', '_blank', 500, 450);
 return false;
}

// Called by the deleteme.php window on a successful delete.
function imdeleted() {
 top.restoreSession();
 location.href = 'transaction/transactions.php';
}

// Compute the length of a string without leading and trailing spaces.
function trimlen(s) {
 var i = 0;
 var j = s.length - 1;
 for (; i <= j && s.charAt(i) == ' '; ++i);
 for (; i <= j && s.charAt(j) == ' '; --j);
 if (i > j) return 0;
 return j + 1 - i;
}

// Validation logic for form submission.
function validate(f) {
 var errCount = 0;
 var errMsgs = new Array();

    <?php generate_layout_validation($form_id); ?>

 var msg = "";
 msg += "<?php echo xla('The following fields are required'); ?>:\n\n";
 for ( var i = 0; i < errMsgs.length; i++ ) {
    msg += errMsgs[i] + "\n";
 }
 msg += "\n<?php echo xla('Please fill them in before continuing.'); ?>";

 if ( errMsgs.length > 0 ) {
    alert(msg);
 }

 return errMsgs.length < 1;
}

function submitme() {
 var f = document.forms['new_transaction'];
 if (validate(f)) {
  top.restoreSession();
  f.submit();
 }
}

<?php if (function_exists($form_id . '_javascript')) {
    call_user_func($form_id . '_javascript');
} ?>

</script>

<style type="text/css">
.form-control {
    width: auto;
    display: inline;
    height: auto;
}
div.tab {
    height: auto;
    width: auto;
}
</style>

</head>
<body class="body_top" onload="<?php echo $body_onload_code; ?>" >
<form name='new_transaction' method='post' action='add_transaction.php?transid=<?php echo attr($transid); ?>' onsubmit='return validate(this)'>
<input type='hidden' name='mode' value='add'>

    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-header">
                    <h1><?php echo xlt('Add/Edit Patient Transaction');?></h1>
                </div>
            </div>
            <div class="col-xs-12">
                <div class="btn-group">
                    <a href="#" class="btn btn-default btn-save" onclick="submitme();">
                        <?php echo xlt('Save'); ?>
                    </a>
                    <a href="transactions.php" class="btn btn-link btn-cancel" onclick="top.restoreSession()">
                        <?php echo xlt('Cancel'); ?>
                    </a>
                </div>
                <hr>
            </div>
        </div>
    </div>

    <table class="text">
        <tr><td>
        <?php echo xlt('Transaction Type'); ?>:&nbsp;</td><td>
<?php
$ttres = sqlStatement("SELECT grp_form_id, grp_title " .
  "FROM layout_group_properties WHERE " .
  "grp_form_id LIKE 'LBT%' AND grp_group_id = '' ORDER BY grp_seq, grp_title");
echo "<select name='title' id='title' onchange='titleChanged()'>\n";
while ($ttrow = sqlFetchArray($ttres)) {
    $thisid = $ttrow['grp_form_id'];
    echo "<option value='" . attr($thisid) . "'";
    if ($thisid == $form_id) {
        echo ' selected';
    }
    echo ">" . text($ttrow['grp_title']) . "</option>\n";
}
echo "</select>\n";
?>
        </td></tr>
    </table>

<div id='referdiv'>

    <?php if ($GLOBALS['enable_amc_prompting'] && 'LBTref' == $form_id) { ?>
        <div style='float:right;margin-right:25px;border-style:solid;border-width:1px;'>
            <div style='float:left;margin:5px 5px 5px 5px;'>

                <?php // Display the send records checkboxes (AMC prompting)
                    $itemAMC = amcCollect("send_sum_amc", $pid, 'transactions', $transid);
                    $itemAMC_elec = amcCollect("send_sum_elec_amc", $pid, 'transactions', $transid);
                ?>

                <?php if (!(empty($itemAMC))) { ?>
                    <input type="checkbox" id="send_sum_flag" name="send_sum_flag" checked>
                <?php } else { ?>
                    <input type="checkbox" id="send_sum_flag" name="send_sum_flag">
                <?php } ?>

                <span class="text"><?php echo xlt('Sent Summary of Care?') ?></span><br>

                <?php if (!(empty($itemAMC)) && !(empty($itemAMC_elec))) { ?>
                    &nbsp;&nbsp;<input type="checkbox" id="send_sum_elec_flag" name="send_sum_elec_flag" checked>
                <?php } else if (!(empty($itemAMC))) { ?>
                    &nbsp;&nbsp;<input type="checkbox" id="send_sum_elec_flag" name="send_sum_elec_flag">
                <?php } else { ?>
                    &nbsp;&nbsp;<input type="checkbox" id="send_sum_elec_flag" name="send_sum_elec_flag" disabled>
                <?php } ?>

                <span class="text"><?php echo xlt('Sent Summary of Care Electronically?') ?></span><br>

            </div>
        </div>
    <?php } ?>

                    <div id="DEM">
                        <ul class="tabNav">
<?php
$fres = sqlStatement("SELECT * FROM layout_options " .
  "WHERE form_id = ? AND uor > 0 " .
  "ORDER BY group_id, seq", array($form_id));
$last_group = '';

while ($frow = sqlFetchArray($fres)) {
    $this_group = $frow['group_id'];
    // Handle a data category (group) change.
    if (strcmp($this_group, $last_group) != 0) {
        $group_seq  = substr($this_group, 0, 1);
        $group_name = $grparr[$this_group]['grp_title'];
        $last_group = $this_group;
        if ($group_seq == 1) {
            echo "<li class='current'>";
        } else {
            echo "<li class=''>";
        }

        $group_seq_esc = attr($group_seq);
        $group_name_show = text(xl_layout_label($group_name));
        echo "<a href='#' id='div_$group_seq_esc'>" .
        "$group_name_show</a></li>";
    }
}
?>
                        </ul>
                        <div class="tabContainer">
<?php
$fres = sqlStatement("SELECT * FROM layout_options " .
  "WHERE form_id = ? AND uor > 0 " .
  "ORDER BY group_id, seq", array($form_id));

$last_group = '';
$cell_count = 0;
$item_count = 0;
$display_style = 'block';
$condition_str = '';

while ($frow = sqlFetchArray($fres)) {
    $this_group = $frow['group_id'];
    $titlecols  = $frow['titlecols'];
    $datacols   = $frow['datacols'];
    $data_type  = $frow['data_type'];
    $field_id   = $frow['field_id'];
    $list_id    = $frow['list_id'];

    // Accumulate action conditions into a JSON expression for the browser side.
    accumActionConditions($field_id, $condition_str, $frow['conditions']);

    $currvalue  = '';
    if (isset($trow[$field_id])) {
        $currvalue = $trow[$field_id];
    }

    // Handle special-case default values.
    if (!$currvalue && !$transid && $form_id == 'LBTref') {
        if ($field_id == 'refer_date') {
            $currvalue = date('Y-m-d');
        } else if ($field_id == 'body' && $transid > 0) {
             $tmp = sqlQuery("SELECT reason FROM form_encounter WHERE " .
              "pid = ? ORDER BY date DESC LIMIT 1", array($pid));
            if (!empty($tmp)) {
                $currvalue = $tmp['reason'];
            }
        }
    }

    // Handle a data category (group) change.
    if (strcmp($this_group, $last_group) != 0) {
        end_group();
        $group_seq  = substr($this_group, 0, 1);
        $group_name = $grparr[$this_group]['grp_title'];
        $last_group = $this_group;
        $group_seq_esc = attr($group_seq);
        if ($group_seq == 1) {
            echo "<div class='tab current' id='div_$group_seq_esc'>";
        } else {
            echo "<div class='tab' id='div_$group_seq_esc'>";
        }

        echo " <table border='0' cellpadding='0'>\n";
        $display_style = 'none';
    }

    // Handle starting of a new row.
    if (($titlecols > 0 && $cell_count >= $CPR) || $cell_count == 0) {
        end_row();
        echo " <tr>";
    }

    if ($item_count == 0 && $titlecols == 0) {
        $titlecols = 1;
    }

    // Handle starting of a new label cell.
    if ($titlecols > 0) {
        end_cell();
        $titlecols_esc = attr($titlecols);
        echo "<td width='70' valign='top' colspan='$titlecols_esc'";
        echo ($frow['uor'] == 2) ? " class='required'" : " class='bold'";
        if ($cell_count == 2) {
            echo " style='padding-left:10pt'";
        }

        // This ID is used by action conditions.
        echo " id='label_id_" . attr($field_id) . "'";
        echo ">";
        $cell_count += $titlecols;
    }

    ++$item_count;

    echo "<b>";

    // Modified 6-09 by BM - Translate if applicable
    if ($frow['title']) {
        echo (text(xl_layout_label($frow['title'])) . ":");
    } else {
        echo "&nbsp;";
    }

     echo "</b>";

    // Handle starting of a new data cell.
    if ($datacols > 0) {
        end_cell();
        $datacols_esc = attr($datacols);
        echo "<td valign='top' colspan='$datacols_esc' class='text'";
        // This ID is used by action conditions.
        echo " id='value_id_" . attr($field_id) . "'";
        if ($cell_count > 0) {
            echo " style='padding-left:5pt'";
        }

        echo ">";
        $cell_count += $datacols;
    }

    ++$item_count;
    generate_form_field($frow, $currvalue);
    echo "</div>";
}

end_group();
?>
</div></div>
</div>
</form>
<p />

<!-- include support for the list-add selectbox feature -->
<?php include $GLOBALS['fileroot']."/library/options_listadd.inc"; ?>

</body>

<script language="JavaScript">

// Array of action conditions for the checkSkipConditions() function.
var skipArray = [
<?php echo $condition_str; ?>
];

<?php echo $date_init; ?>
// titleChanged();
<?php
if (function_exists($form_id . '_javascript_onload')) {
    call_user_func($form_id . '_javascript_onload');
}
?>

</script>

</html>
