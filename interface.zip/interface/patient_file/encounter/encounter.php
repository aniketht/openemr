<?php
include_once("../../globals.php");
?>

<html>
<head>
<?php html_header_show();?>


<link rel="stylesheet" href="<?php echo $css_header;?>" type="text/css">


</head>
<body class="body_top">

<span class="title"><?php xl('Walt Pennington', 'e'); ?></span><br>


<table border=0 cellpadding=0>

<tr>
<td><div class="text"><?php xl('Info test 1', 'e'); ?></div></td>
<td><div class="text"><?php xl('Info test 2', 'e'); ?></div></td>
<td><div class="text"><?php xl('Info test 3', 'e'); ?></div></td>
</tr>

<tr>
<td><div class="text"><?php xl('Info test 4', 'e'); ?></div></td>
<td><div class="text"><?php xl('Info test 5', 'e'); ?></div></td>
<td><div class="text"><?php xl('Info test 6', 'e'); ?></div></td>
</tr>

</table>



<div class="text">asdfasdttf this is stuff</div>

<span class="text">asdfasdttf this is stuff</span>


<br><br>




<br><br>

</body>
</html>
