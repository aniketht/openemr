<?php
/*
 * Created on Dec 17, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
include_once("../../globals.php");

?>
<html>
<head>
<?php html_header_show();?>


<link rel="stylesheet" href="<?php echo $css_header;?>" type="text/css">

</head>
<body class="body_bottom">

<!--
<table border=0 cellspacing=0 cellpadding=0 height=100%>
<tr>
<td background="<?php echo $linepic;?>" width=7 height=100%>
&nbsp;
</td>
</tr>
</table>
-->

</body>
</html>
